#include <iostream>
using namespace std;

 void functoins()
 {
   string name ;
   cout << " name : " ;
    getline(cin, name) ;
 }
int main() 
{
    functoins() ;
    return 0;
}