#include <iostream>
#include <cmath>
using namespace std;

void reednumbers (float &a , float &b) 
{
 cout << " enter the number a : " ;
 cin >> a ;

 cout << " enter the number b : " ;
 cin >> b ; 
}

float calculatenumbers (float a , float b )
{
     const float pi = 3.141592653589793238 ;
     float resalt = pi * (pow(b, 2) / 4 ) * ((2 * a - b ) / (2 * a + b )) ;

 return resalt ; 
}
 void print ( float resalt ) 
 {
    cout << " the area  is : " << resalt  << endl ;
 }


int main() 
{
    float a, b ;
   reednumbers (a ,b) ;
   print(calculatenumbers(a, b)) ;

    return 0;
}