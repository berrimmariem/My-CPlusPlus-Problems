#include <iostream>
using namespace std;

 bool functoins(int number) {
  if (number % 2 == 0 ) {
    return true ;
  } else {
    return false ;
  }

 }
  
 
   
 
int main() 
{
     cout << functoins(7) ;
    return 0;
}