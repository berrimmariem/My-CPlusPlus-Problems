#include <iostream>
using namespace std;

enum ennumtype {odd = 1 , even = 2 } ;


int reednumber ()
{

 int num ;
 cout << " enter your number : " << endl ;
 cin >> num ;

 return num ; 
}

 ennumtype checknumber (int num )
{
   int result = num % 2 ;
   if (num==0)
  {
  return ennumtype::even;
  }

 else 
 {
  return ennumtype::odd ;
 }

}
 void printnumber (ennumtype numbertype ) 
{
  if (numbertype == ennumtype :: even ) 
  {
    cout << " \n your number is even\n  " ;
  }
  else 
  {
    cout << " \n your number is odd\n  " ;
  
  }

}

int main() 
{
    printnumber(checknumber (reednumber())) ;

    return 0;
}