#include <iostream>
using namespace std;

  int checkage (int from ,int to ) 
  {
  int number ; 
  cout << " enter your age " << endl ; 
  cin >> number ;

  while ( number < from || number > to ) 
 {
  cout << "wrong age , please enter a age between  "<< from << " and " << to << endl ;
  cin >> number ;
 }
 return number ;  
 }
  
int main() 
{

    cout  << checkage(18 , 45 ) << endl ;
    return 0;
}