#include <iostream>
using namespace std;

int main() 
{
  int n ;
  cout << " enter your number : " << endl ;
  cin >> n ;
    for (  int  i = n ; i >= 1 ; i-- )  {
    cout << i << endl ;
    
    }
    cout << endl ;
    return 0;
}