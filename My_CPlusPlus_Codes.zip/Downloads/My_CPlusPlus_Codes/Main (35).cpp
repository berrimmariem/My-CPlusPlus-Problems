#include <iostream>
#include <cmath>
using namespace std;

  void functoins(int a, int b, int c)
  {
   float p = (a+b+c ) /2 ;
   float area = (a*b*c)/(4*sqrt(p*(p-a)*(p-b)*(p-c))) ;
   float areatotal = pow(area, 2) ;
   cout << "area =  " << areatotal ;

  

 }
  
 
   
 
int main() 
{
      functoins(5,6,7) ;
    return 0;
}