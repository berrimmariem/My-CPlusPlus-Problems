#include <iostream>
using namespace std;

float reednumber (string message ) 
{
    float number = 0 ;
    cout << message << endl ;
    cin >> number ;

   return number ;
}
float caculation (float la ,float lp) 
{
 return la / lp ;
}
int main() 
{
    float la = reednumber ("enter your number : ") ; 
    float lp = reednumber ("enter your number : ") ;

    cout << " total months is : \n"  << caculation (la , lp) << " months " ;

    return 0;
}