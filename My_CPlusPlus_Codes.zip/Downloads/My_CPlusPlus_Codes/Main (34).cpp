#include <iostream>
using namespace std;

 void functoins() {

  int number1, number2, number3  ;
  
  cout << " enter number1 and number2  :" ;
   cin >> number1 >> number2   ;
   number3 = number1 ;
   number1 = number2 ;
   number2 = number3;

  cout << number1 << number2 ;
  

 }
  
 
   
 
int main() 
{
      functoins() ;
    return 0;
}