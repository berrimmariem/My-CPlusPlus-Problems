#include <iostream>
#include <string>
using namespace std;

struct stvariables 
{
 short age ;
 bool driver_license  ;

} ;
 void read(stvariables&mimi)
 {
    cout << " enter your age : " ;
    cin >>  mimi.age ;
    cout << " did you have a driver license ?  (1 for true ,0 for false ): " ;
    cin >> mimi.driver_license ;
 } 
 void prant(stvariables&mimi)
 {
    if (mimi.age>=21 && mimi.driver_license==true) 
    {
  cout << " hired " ;
    }
     else if (mimi.age<21 || mimi.driver_license == false ) 
    {
        cout << " rejected " ;
    }
 }

int main() 
{
    stvariables mimi; 
  read(mimi) ;
  prant(mimi) ;
    return 0;
}