#include <iostream>
#include <cmath>
using namespace std;

int reednumber (string message ) 
{
    int number = 0 ;
    cout << message << endl ;
    cin >> number ;

   return number ;
}
 float checknumber (int number)
 {
    int totalbill = reednumber ("enter your number : ") ;
    int totalckachbill = reednumber ("enter your number : ") ;

   float result = (totalbill+totalckachbill) / 2 ;
  return result ;

 }

int main() 
{
int number ;
    cout  << checknumber(number) << endl ;
    return 0;
}