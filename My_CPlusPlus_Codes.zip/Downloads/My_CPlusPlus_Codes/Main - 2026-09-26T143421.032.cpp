#include <iostream>
using namespace std;

void printtable () 
{
   cout << "\n\n\t\t Multiplication Table \n\n " ; 
   cout << "\t" ;
    for (int i = 1 ; i <= 10 ; i++) 
    {
      cout << i << "\t" ;
    }
   cout << "\n___________________________________________________________________________________\n";
}

 string checknumber (int i)  
 {
    if (i < 10)
    return  "   |" ;

    else 
    return  "  |" ;
 }
 void printMultiplicationtable () 
 {
    printtable() ;
    for ( int i = 1 ; i <= 10 ; i++) 
    {
        cout << i << checknumber(i) << "\t" ;
         for ( int j = 1 ; j <= 10 ; j++) 
        {
            cout << i*j << "\t" ;
        }
        cout << endl ;
    }
 }

 
int main() 
{
    printMultiplicationtable() ;
    return 0;
}