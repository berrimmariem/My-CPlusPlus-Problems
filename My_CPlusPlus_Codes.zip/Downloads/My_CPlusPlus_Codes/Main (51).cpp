#include <iostream>
using namespace std;

 enum enweekday {sun = 1 , mon , tue , wed , thu , fri , sat } ;

  void showweekdaymenue() 
  {
   cout <<"________________________________________\n" ;
   cout <<"            week day                    \n" ;
   cout <<"________________________________________\n" ;
   cout << " 1 : sun " << endl ;
   cout << " 2 : mon " << endl ;
   cout << " 3 : tue " << endl ;
   cout << " 4 : wed " << endl ;
   cout << " 5 : thu " << endl ;
   cout << " 6 : fri " << endl ;
   cout << " 7 : sat " << endl ;
   cout <<"________________________________________\n" ; 
   cout << " enter the  number of day " << endl ;
  }
   enweekday readweekday() {

   enweekday weekday ;

   int numday ;
   cin >> numday ;
   return ( enweekday ) numday ;
   }
 string getwd(enweekday weekday) {

  switch (weekday) {
        case  enweekday:: sun :
          return "sunday" ;
        break ;
        case   enweekday::mon :
          return  " manday " ;
        break ;
        case  enweekday::tue :
          return "tuesday" ;
        break ;
        case enweekday:: wed :
         return "wednesday" ;
        break ;
        case enweekday:: thu :
         return "thursday" ;
        break ;
        case enweekday:: fri :
         return "friday" ;
        break ;
        case enweekday:: sat :
         return "saturday" ;
        break ;
        default :
         return " not a week day\n " ;
    
    }


 }
int main() 
{
   showweekdaymenue() ;
     cout << " today is : " << getwd (readweekday()) << endl ;
    return 0;
}