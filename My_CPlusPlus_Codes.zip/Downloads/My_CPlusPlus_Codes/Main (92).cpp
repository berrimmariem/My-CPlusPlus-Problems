#include <iostream>
using namespace std;

int reednumber ()
{
    int num ;
    cout << "please enter your number : " ;
    cin >> num ;
    
    return num ;
}
 float calculatehalfnumber (int num)
 {
    return (float) num / 2 ;
 }
 void printresult(int num)
 {
   string result = " half of " +to_string(num) + " is " + to_string(calculatehalfnumber(num)) ;
   cout << endl << result << endl ;
 }

int main() 
{
    printresult(reednumber()) ;
    return 0;
}