#include <iostream>
#include <string>
using namespace std;

struct stmoney 
{
    int p , n , d , q , dl ;
} ;
stmoney reeddate () 
{
    stmoney m ;

    cout << "Enter Pennies: ";
    cin >> m.p;
    
    cout << "Enter Nickels: ";
    cin >> m.n;
    
    cout << "Enter Dimes: ";
    cin >> m.d;
    
    cout << "Enter Quarters: ";
    cin >> m.q;
    
    cout << "Enter Dollars: ";
    cin >> m.dl;
    
    return m;
}
float calculation (stmoney m)
{
    float total ;
    total = m.p * 1 + m.n * 5 + m.d * 10 + m.q * 25 + m.dl * 100 ;
    return total ;
}

int main() 
{
    float total = calculation(reeddate()) ;
    cout << "\n Total Pennies is : \n" << total << endl ;
    cout << "\n Total Pennies is : \n" << total/100 << endl ;


    return 0;
}