#include <iostream>
#include <cmath>

using namespace std;

  void reednumbers(float & a , float & d ) 
  {
    cout << " please enter the length of the rectangle :  " ;
    cin >> a ; 

    cout << " please enter rectangle display :  " ;
    cin >> d ;  
  }
  float calculateareaof​​arectangle (float a , float d ) 
  {
    float area = a * sqrt (pow (d, 2)- pow (a,2))  ; 
    return area ;
  }
  void printresult( float area) 
  {
    cout << " \n the area of​ ​arectangle is :  " << area << endl ;
  }
int main() 
{
  float a , d ;
  reednumbers(a , d) ;
  printresult(calculateareaof​​arectangle(a,d)) ;
    return 0;
}