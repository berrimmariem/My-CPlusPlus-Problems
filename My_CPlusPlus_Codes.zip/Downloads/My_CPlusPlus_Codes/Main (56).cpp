#include <iostream>
using namespace std;

 enum  ennumbertype { odd = 1 , even = 2 } ;
 
 ennumbertype checknumbertype (int number) {


  if ( number % 2 == 0 ) 
  return ennumbertype::even  ;

  else 
  return ennumbertype :: odd ; }

  int sumnumber ( int n ) 
 {
  int sum = 0  ;

  for ( int i = 0 ; i <= n ; i=i+2  ) {

  if (checknumbertype(i) == ennumbertype::even) {

  sum = sum + i  ; }

  }
 return sum ;  } 

 void printresults ( int n ) {

 cout << "sum of odd number "  << sumnumber(n) << endl ;
}
 
   
int main() 
{
    int n ;
    cout << " enter your number : " ;
    cin >> n ; 

    printresults(n) ;

    return 0;
}