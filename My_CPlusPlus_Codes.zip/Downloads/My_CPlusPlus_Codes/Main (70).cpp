#include <iostream>
using namespace std;

int main() 
{
    int num ;
    cout <<" please enter your positve number : \n" ; 
    cin >> num ;

    while (num<0) {
     cout << " wrong number , please enter your positve number : \n " ; 
     cin >> num ;
    }
  cout << " good work , your number ( " << num << " ) is a positve number " ;

    return 0;
}