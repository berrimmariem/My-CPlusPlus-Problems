#include <iostream>
#include <cmath>
using namespace std;

void reednumbers (float &a , float &b , float &c) 
{
 cout << " enter the number a : " ;
 cin >> a ;

 cout << " enter the number b : " ;
 cin >> b ; 

 cout << " enter the number c : " ;
 cin >> c ; 

}

float calculatenumbers (float a , float b , float c )
{
     const float pi = 3.141592653589793238 ;
     float p = (a + b + c) / 2 ;
     float area = (a * b * c) / (4 * sqrt(p* (p - a) * ( p - b) * (p -c ))) ;
     float result = pi * pow(area, 2) ;
 return result ; 
}
 void print ( float resalt ) 
 {
    cout << " the area  is : " << resalt  << endl ;
 }


int main() 
{
    float a, b, c ;
   reednumbers (a ,b ,c) ;
   print(calculatenumbers(a, b ,c)) ;

    return 0;
}