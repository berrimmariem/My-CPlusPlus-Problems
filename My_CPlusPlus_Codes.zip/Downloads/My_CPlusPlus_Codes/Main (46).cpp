#include <iostream>
using namespace std;

int main()
{
    int mark ;
    cout << " enter the mark : " ;
    cin >> mark ;
    
    if ( mark >= 50 )
    {
        cout << " pass " ;
    }
    else 
    {
        cout << " fail " ;
    }
    
    return 0;
}
