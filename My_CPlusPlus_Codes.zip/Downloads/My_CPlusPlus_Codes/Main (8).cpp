#include <iostream>
using namespace std;

int main() 
{
    short int p ;
    short int n ;
    short int d ;
    short int q;
    short int di ;

    cout << "please enter a p : " << endl ;
    cin >> p ;
    cout << "please enter a n : " << endl ;
    cin >> n ;

    cout << "please enter a d : " << endl ;
    cin >> d ;

    cout << "please enter a q : " << endl ;
    cin >> q ;

    cout << "please enter a di : " << endl ;
    cin >> di ;
    int total = p + n+d+ q +di ;

    cout << p * 1  << n*5  << d*10  << q *15 << di * 20 << endl ;

  cout << total ;





    return 0;
}