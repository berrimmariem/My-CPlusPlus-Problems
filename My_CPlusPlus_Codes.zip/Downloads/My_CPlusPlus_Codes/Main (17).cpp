#include <iostream>
#include <cmath>
using namespace std;

int main() 
{
    short int a  ;
    short int b  ;

    short int pi = 3.14 ;

      cout << " please enter the num1 : \n " ;
       cin >> a ;
      cout << " please enter the num1 : \n " ;
       cin >> b ; 

        double area = (( pi * pow (b, 2))/4 ) * (( 2 * a - b ) / ( 2 * a- b )) ;
          cout << " area = " <<  floor (area) << endl ;



    return 0;
}