#include <iostream>
using namespace std;

int main()
{
    int age ;
    cout << " enter the age : " ;
    cin >> age ;
    
    if ( age >= 18 && age <=45 )
    {
        cout << " pass " ;
    }
    else 
    {
        cout << " fail " ;
    }
    
    return 0;
}
