#include <iostream>
#include <string>

using namespace std; 


struct stvareble {

 string firstname ;
 string lastname ;
 short age ;
 string num_of_phone ; 
 } ;

 void readcard (stvareble&card) {
 cout << " enter your first name : " << endl ;
 cin >> card.firstname ;

 cout << " enter your last name : " << endl ;
 cin >> card.lastname ;

 cout << " enter your age : " << endl ;
 cin >> card.age ;

 cout << " enter your number of phone : " << endl ;
 cin >> card.num_of_phone ;

 }
 void printcard ( stvareble card ) {

 cout << "\n***********************************************\n" ;
 cout << " first name : " << card.firstname << endl  ;
 cout << " last name : " << card.lastname << endl  ;
 cout << " age : " << card.age << endl  ;
 cout << " number of phone : " << card.num_of_phone << endl  ;
 cout << "\n***********************************************\n" ;

 }
 

int main() 
{
  stvareble persons [100] ;

int numofpersons = 0 ;
cout << "How many persons do you want to enter (Max 100)? ";
cin >> numofpersons ; 

 cout << "\n=== Start Entering Data ===\n";

   for ( int i = 0 ; i < numofpersons ; i++) {

   cout << " \n Entering data for Persons " << i + 1 << ":\n";
   readcard(persons[i]) ;

   }
   cout << "\n=== Displaying All Persons ===\n";

    
    for (int i = 0; i < numofpersons; i++) {
        printcard(persons[i]); 
    }

    return 0;
}