#include <iostream>
#include <string>


using namespace std;

struct stinfo 
{
    short age ;
    bool hasdriverlicense ;
} ;

stinfo reedinfo ()
{
    stinfo info ;

    cout << "enter your age : " ;
    cin >> info.age ;

    cout << "do you have driver license ? : " ;
    cin  >> boolalpha >> info.hasdriverlicense ;

    return info ;
}

bool isaccepted (stinfo info )
{
    return (info.age > 21 && info.hasdriverlicense) ;
} ;

void printinfo(stinfo info) 
{
    if (isaccepted(info))
    
        cout << " \n hired \n " ;
    
    else 
    
        cout << " \n rejcted \n " ;
    
}

int main() 
{
    printinfo(reedinfo()) ;

    return 0;
}