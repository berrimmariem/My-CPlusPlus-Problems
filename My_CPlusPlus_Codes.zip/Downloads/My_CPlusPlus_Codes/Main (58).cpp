#include <iostream>
using namespace std;

int main() 
{
    int n ;
    cout << " enter your number : " ;
    cin >> n ;
    int f = n - 1 ;


    for (int i = 1 ; i <= n ; i++){
        f = f * i ;
        cout << f  << endl;
    }
    return 0;
}