#include <iostream>
using namespace std;

void reednum ( int & num ) 
{
    cout << "enter your number : \n " ;
    cin >> num ;
}
void numbers ( int num,int & num1 , int & num2 , int & num3 ) 
{
     num1 = num*num ; 
     num2 = num*num*num ;
     num3 = num*num*num*num ; 

}
 void printnumbers (int num1 , int  num2 , int  num3 ) 
 {
    cout << "the result is : \n " ;
    cout << num1 << endl << num2 << endl << num3 << endl ; 
 }

int main() 
{
    int num ; 
    reednum(num) ;
    int nu1 =0, nu2=0, nu3=0 ;
    numbers (num ,nu1 , nu2, nu3 ) ;
    printnumbers(nu1 , nu2, nu3 ) ;

    return 0;
}