#include <iostream>
#include <cmath>

using namespace std;

  void reednumbers(float & a , float & d , float & c ) 
  {
    cout << " please enter the number :  " ;
    cin >> a ; 

    cout << " please enter number :  " ;
    cin >> d ;  

    cout << " please enter number :  " ;
    cin >> c ;
  }
  float calculateareaof​​arectangle (float a , float d , float c ) 
  {
     const float pi = 3.14159265358979323846264338327950288419716939937510 ;
     float p = (a + d + c) / 2 ;
    float t = (a*d*c) / (4 * sqrt(p*(p-a) * (p- d) * (p-c))) ;
     float area = pi * pow(t, 2) ;
    return area ;
  }
  void printresult( float area) 
  {
    cout << " \n the area of​ ​arectangle is :  " << area << endl ;
  }
int main() 
{
  float a , d , c ;
  reednumbers(a , d, c) ;
  printresult(calculateareaof​​arectangle(a,d,c)) ;
    return 0;
}