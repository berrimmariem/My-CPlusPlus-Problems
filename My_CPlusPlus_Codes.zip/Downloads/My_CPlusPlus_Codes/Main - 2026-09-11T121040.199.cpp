#include <iostream>
using namespace std;

float reednumber (string message ) 
{
    float number = 0 ;
    cout << message << endl ;
    cin >> number ;

   return number ;
}
void checknumber ( float number )
{
    for (int i = 3; i > 0 ; i-- )
    {
        if (number == 1234 )
        {
        cout << " Your blanece is : 7500 \n " ;
        break ;
        }
        else 
        cout << " wrong number , you have " << i-1 << " try\n" ;
        
        if (i > 1 ) 
        {
            cout << " enter your number again \n " ;
            cin >> number ;
        }
    }
} 
int main () 
{
    int number = reednumber (" please enter your number : \n") ;
    checknumber (number) ;
    return 0 ;
}