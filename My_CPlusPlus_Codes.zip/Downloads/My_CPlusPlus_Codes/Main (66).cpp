#include <iostream>
using namespace std;

int main() 
{
     for ( char c = 'A'; c <= 'F' ; c++)  
     {
        
        for ( char j = 'A'; j<= c ; j++) 
        {
            cout << j  ;
         
        }
        
        
            
      cout << endl ; 


        
     }

    return 0;
}