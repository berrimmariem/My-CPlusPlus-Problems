#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

float reednumber (string message ) 
{
    float number = 0 ;
    cout << message << endl ;
    cin >> number ;

   return number ;
}
 float calculationnumofdays (float days)
 {
  return days * 86400 ;
 }
 float calculationnumofweeks(float weeks ) 
 {
    return weeks * 604800 ;
 }
 float calculationnumofhours (float hours )
 {
    return hours * 3600 ; 
 }
 float calculationnumofminute (float minutes ) 
 {
    return minutes * 60 ;
 }
 float calculationtotalofs (float days , float weeks , float hours , float minutes )
 {
    return   calculationnumofdays(days) + calculationnumofweeks(weeks) + calculationnumofhours(hours) + calculationnumofminute (minutes) ;
 }
int main() 
{ 
     float days =  reednumber( "enter the number of days : ")  ;
     float weeks = reednumber( "enter the number of weeks : ")  ;
     float hours = reednumber( "enter the number of hours : ")  ;
     float minutes = reednumber( "enter the number of minutes : ")  ;

     
     cout << " tatal of s is : "<< fixed << calculationtotalofs(days , weeks , hours , minutes) ;
    
}