#include <iostream>
using namespace std;

int main() 
{
    const float pi = 3.14 ;
    short int a ;

    cout << "please enter a a : " << endl ;
    cin >> a ;

    float area = (a*a) /( 4 * pi) ;
    cout << " area = (a*a) /( 4 * pi) " << endl ;


    cout << "      = (" << a << "*" << a << " ) / (" << pi << "*4 )" << endl ;
    cout << "      = " << area << endl ;



    return 0;
}