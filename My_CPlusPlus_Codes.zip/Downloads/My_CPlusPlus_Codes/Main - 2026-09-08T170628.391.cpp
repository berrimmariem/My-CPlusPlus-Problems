#include <iostream>
#include <cmath>
using namespace std;

 void reednum (int& num , int& m)
 {
    cout << "enyer your number : \n " ;
    cin >> num ; 
    
    cout << "enyer your number2 : \n " ;
    cin >> m ; 
 }

 int numbers (int num ,int m)
 {
     int result = pow(num, m) ; 
     return result ;
 }
 void print ( int result) 
 {
   cout << " The result is : \n " << result << endl ; 
 }
 


int main() 
{
    int num , m ;
    reednum (num , m) ;
    print(numbers(num , m)) ;
    return 0;
}