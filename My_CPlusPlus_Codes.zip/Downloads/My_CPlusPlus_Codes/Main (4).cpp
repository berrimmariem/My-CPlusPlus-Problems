#include <iostream>
using namespace std;

int main() 
{
    short int a ;
    short int h ;

    cout << "please enter a a : " << endl ;
    cin >> a ;

    cout << "please enter a h : " << endl ;
    cin >> h ;

    short int area =( a * h ) /2 ;
    cout << " area = ( a * h ) / 2" << endl ;


    cout << "      = (" << a <<" * " << h << ") / 2" << endl ; 
    cout << "      = " << area << endl ;



    return 0;
}