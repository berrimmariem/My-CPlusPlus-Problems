#include <iostream>
using namespace std;

enum enlama {a = '+' , s = '-' , m = '*' , d = '/'} ;

void reednumbers (int & num1 , int & num2) 
{
   cout << " enter the first number : \n " ; 
   cin >> num1 ; 

   cout << " enter the second number : \n " ; 
   cin >> num2 ;
}
enlama reedsign() 
{
    char sign ;
    cout << " enter a sign : " ;
    cin >> sign ;

    return (enlama)sign ;
}
 float caluclion (int num1 , int num2 ,enlama op) 
{
  switch (op) 
  {
     case a : return num1+num2 ;
     case s : return num1-num2 ;
     case m : return num1*num2 ;
     case d :

     if (num2 == 0 ) 
     {
       cout << "Error! Division by zero.\n";
        return 0;
     }
            return (float) num1 / num2 ;

     default:
     cout << "Invalid operation!\n";
     return 0;
  
   }
}
 
int main() 
{
  int num1 , num2 ;
   reednumbers ( num1 , num2) ;

   enlama op = reedsign() ;

    cout << "the result is : \n" << caluclion (num1 ,num2 , op) << endl ;

    return 0;
}