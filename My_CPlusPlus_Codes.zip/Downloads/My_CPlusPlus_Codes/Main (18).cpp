#include <iostream>
using namespace std;

int main() 
{
 struct card 
  {
    string name ; 
    int  age ; 
    string city ; 
    string country ; 
     int  monthlysalary ; 
      int yearlysalary ; 
     char  gender ;
     bool married  ;
  } ;
  
    card mycard ; 
    cout <<"*****************************************\n " ;
    cout << " Name : " ;
    cin >> mycard.name ;
    cout << " Age : " ; 
    cin >> mycard.age ;
    cout << " city : " ; 
    cin >> mycard.city ; 
    cout << " country : " ; 
    cin >> mycard.country ;
    cout << " monthly salary : " ;
    cin >> mycard.monthlysalary ;
    cout << " yearly salary : " ; 
    cin >> mycard.yearlysalary ;
    cout << " gender : " ; 
    cin >> mycard.gender;
    cout << " married : "  ; 
    cin >> mycard.married ;
    cout <<"*****************************************\n " ;



















    return 0;
}

