#include <iostream>
#include <cmath>

using namespace std;

  float reednumbers() 
  {
    float r ;
    cout << " please enter the r :  " ;
    cin >> r ; 

    return r ;
  }
  float calculateareaof​​arectangle (float r ) 
  {
    const float pi = 3.1415926535 ;

    float area = pi * pow(r, 2) / 4 ; 
    return area ;
  }
  void printresult( float area) 
  {
    cout << " \n the area of​ ​arectangle is :  " << area << endl ;
  }
int main() 
{
  printresult(calculateareaof​​arectangle(reednumbers())) ;
    return 0;
}