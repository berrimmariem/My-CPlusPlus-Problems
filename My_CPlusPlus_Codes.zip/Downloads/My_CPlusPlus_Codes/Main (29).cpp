#include <iostream>
using namespace std;

  int  mysumfunction() 
{
  int num1 ; 
  int num2 ;
  cout << " please enter num 1 : " ;
  cin >> num1 ;
  cout << " please enter num 2 : " ;
  cin >> num2 ;
cout << "---------------------------------------\n" ;
   
   return  num1 + num2 ;

} 

int main() 
{
    cout << mysumfunction() ;
 
    return 0;
} 