#include <iostream>
using namespace std;


 struct engine
  {
    int horsepawer ;
    string fuel_type ;
  } ;
struct car 
{
  string brand ;
  int price ;
  engine eng ;
} ;
int main() 
{
     car owaner1 ;
    cout << "____________________________________________________\n" ;
  cout << " brand : "  <<endl ;
  cin >> owaner1.brand ;
  cout << " price : " << endl ;
  cin>> owaner1.price ;
  cout << " horsepawer : " << endl ;
  cin>> owaner1.eng.horsepawer;
  cout << " fuel type : "<< endl ;
  cin>> owaner1.eng.fuel_type ;
    cout << "____________________________________________________\n" ;

    
    return 0;
}