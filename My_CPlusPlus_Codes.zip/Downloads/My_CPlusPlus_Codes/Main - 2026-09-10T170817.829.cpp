#include <iostream>
#include <string>
using namespace std;

enum thenumbersofthedays {sunday = 1 , monday , tuesday , wednesday , thursday , friday ,saturday } ;

float reednumber (string message ) 
{
    float number = 0 ;
    do 
    {
       cout << message << endl ;
        cin >> number ; 

        if ( number < 1 || number > 7 ) 
        cout << " wrong number , enter a number between 1 and 7 \n " ; 
    }
       while (number < 1 || number > 7) ; 
   return number ;
}
 thenumbersofthedays checknumofdays ( int number) 
 {
    switch (number ) 
    {
        case 1 : return sunday ; 
        case 2 : return monday ; 
        case 3 : return tuesday ; 
        case 4 : return wednesday ; 
        case 5 : return thursday ; 
        case 6 : return friday ; 
        case 7 : return saturday ; 

     default: return sunday;
    }
 
}
void printday (thenumbersofthedays day) 
{
    switch (day) 
    {
        case sunday : cout << " sunday " ; break ; 
        case monday : cout << " Monday " ; break ; 
        case tuesday : cout << " Tuesday " ; break ; 
        case wednesday : cout << " Wednesday " ; break ; 
        case thursday : cout << " Thursday " ; break ; 
        case friday : cout << " Friday " ; break ; 
        case saturday : cout << " Saturday " ; break ; 
     
    
    }
     cout << endl ;
}
 
int main () 
{
     int number = reednumber (" enter your number of day : ") ;
     thenumbersofthedays day = checknumofdays(number) ;

     cout << "the day is : \n " ;
     printday(day) ;
     return 0 ;

}
