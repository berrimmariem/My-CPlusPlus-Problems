#include <iostream>
using namespace std;

int main() 
{
    short int L ;
    short int l ;

    cout << "please enter a L : " << endl ;
    cin >> L ;
    
    cout << "please enter a l : " << endl ;
    cin >> l ;

    short int area =(L * l ) ;


    cout << L <<" * " << l <<" = "<< area << endl ; 



    return 0;
}