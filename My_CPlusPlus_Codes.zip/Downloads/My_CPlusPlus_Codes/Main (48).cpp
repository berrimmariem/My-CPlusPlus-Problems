#include <iostream>
using namespace std;

int main()
{
    int gender ;
    cout << " enter the gender : " ;
    cin >> gender ;
    
    if ( gender>=90 )
    {
        cout << " A " ;
    }
    else if ( gender>= 80 )
    {
        cout << " B " ;
    }
    else if ( gender>= 70 )
    {
        cout << " C " ;
    }
    else if ( gender>= 60 ) 
    {
        cout << " D " ;
    }
    else if ( gender>= 50 )
    {
        cout << " E " ;
    }
    else 
    {
        cout << " F " ;
    }
    
    return 0;
}
