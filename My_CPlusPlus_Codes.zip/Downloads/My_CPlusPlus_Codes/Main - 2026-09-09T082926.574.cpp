#include <iostream>
using namespace std;

void reednumber (int & number) 
{
    cout << " enter your number : \n" ;
    cin >> number;
}
float calculation ( int & number )
{
    float sum = 0 ;
    do 
    {
      if (number == -99) 
      {
        break ;
      }
      sum +=number ;
      reednumber(number) ;
    }
     while (number != -99) ;
    
        return sum ;
    
      
}
int main() 
{
    int number ;
    reednumber (number); 
     cout  << calculation (number) ;
    return 0;
}