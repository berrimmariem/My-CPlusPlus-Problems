#include <iostream>
using namespace std;


int main() 
{
int n ;
 int sum = 0 ;
cout << "please enter yout number :. " << endl ; 
cin >> n ;

for (int c = 1 ; c <= n ; c++ ) {
 
 if (c % 2 != 0 ) {
sum = sum + c ;
 
  

}
}


  cout << sum ;
    
    return 0;
}