#include <iostream>
using namespace std;

int main() 
{
    int n ;
    cout << " enter your number : " ;
    cin >> n ;
    int f =  1 ;


    for (int i = n ; i >= 1 ; i--){
        f = f * i ;
        
    }
    cout << "result : " << f  << endl;
    return 0;
}