#include <iostream>
using namespace std;

 int reednum ()
 {
    int num ;
    cout << "enyer your number : \n " ;
    cin >> num ; 

    return num ;
 }
 void numbers (int num)
 {
    int a,b,c ;
    a = num * num ;
    b = num * num * num ; 
    c = num * num * num * num ; 
    cout << a << endl << b << endl << c << endl ; 
 }


int main() 
{
  numbers(reednum()) ;
    return 0;
}