#include <iostream>
using namespace std;

string reedname() 
{
 string name ;
  cout << " enter your name : " << endl ;
  getline(cin, name) ;
  return name ;
}

void printname (string name) 
{
   cout <<" \n your name is : " << name << endl ;
}
int main() 
{

    printname(reedname()) ;
    return 0;
}