#include <iostream>
#include <string>
using namespace std;

struct stinfo 
{
    string firstname ;
    string lastname  ;  
} ;
stinfo reedinfo()
{
  stinfo info ;

    cout << "enter your first name : " ;
    cin >> info.firstname ;

    cout << "enter your last name : " ;
    cin >> info.lastname ;

  return info ;
}
 string getfullename(stinfo info, bool reversed) 
 {
     string fullename = " " ;

     if (reversed)
     fullename = info.lastname + " " + info.firstname ;

     else 
     fullename = info.firstname + " " + info.lastname ;

     return fullename ;
 }
 void printfullename(string fullename)
 {
    cout << "\n - your fulle name is : " << fullename << endl ;
 }

int main() 
{
    bool reversed ;
    cout << "\n reversed \n" ;
    cin >> boolalpha >> reversed ;

    printfullename(getfullename(reedinfo(),reversed)) ;
    return 0;
}