#include <iostream>
using namespace std;

float reednumber (string message ) 
{
    float number = 0 ;
    cout << message << endl ;
    cin >> number ;

   return number ;
}
float caculation (float la ,float months) 
{
 return la / months ;
}
int main() 
{
    float la = reednumber ("enter your number : ") ; 
    float months = reednumber ("enter your number : ") ;

    cout << "  is : \n"  << caculation (la , months)  ;

    return 0;
}