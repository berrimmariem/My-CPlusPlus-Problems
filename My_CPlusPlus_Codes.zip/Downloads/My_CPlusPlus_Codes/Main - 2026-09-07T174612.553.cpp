#include <iostream>
using namespace std;

enum typeofnumber{ odd = 1 , even } ;

void reednumber (int& num) 
{
  cout << "enter your number : " ;
  cin >> num ;
}
void sumofoddnumber ( int & sum , int num )
{
     sum = 0 ;
    for (int i = 0 ; num >= i ; i++) 
    {
        if ( i % 2 == 0 )
        {
            sum = sum + i ; 
        }
    }
}
void print ( int sum ) 
{
    cout << " the sum of even numbers on your number is : \n " << sum << endl ;
}

int main() 
{
  int num ;
  int sum = 0 ;
  reednumber (num) ;
  sumofoddnumber (sum , num) ;
  print (sum) ;
    return 0;
}