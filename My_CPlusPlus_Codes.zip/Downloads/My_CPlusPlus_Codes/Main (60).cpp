#include <iostream>
#include <cmath>

using namespace std;

int main() 
{
  cout << "______capital latters______" << endl ;
   for ( char c =  'A'; c <= 'Z'; c++ ) {
   cout << c << endl ; } 
   

    return 0;
}