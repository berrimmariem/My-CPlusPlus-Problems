#include <iostream>
using namespace std;

int main() 
{



    int num ;
    cout <<" please enter a positve number " ;
    cin >> num ;
     
     while (num < 0 ) {
     cout <<" wrong number , please enter a positve number : " ;
     cin >> num ;
     }
    int sum = 1 ;


    for (int i = 1 ; i <= num ; i++ ) {
    
    
    sum = sum * i ; 
    
    }
    cout << sum ;

    
    return 0;



}