#include <iostream>
using namespace std;

void reednum (int& num) 
{
    cout << " please enter your number : \n " ;
    cin >> num ; 
}
void checknum ( int num ) 
{
    for (int i = num ; i > 0 ; i--) 
    {
      cout << i << endl ; 
    } 
 }
 void checknumnum2 (int num ) 
 {
    cout << "________________________\n" ; 
     int conter = num ;
    do 
    {
         (conter > 0) ;
        cout << conter << endl ;
        conter-- ;
    }
    while (conter > 0 )  ;
    
 }
 
int main() 
{
    int num ;
    reednum (num) ;
    checknum(num) ;
    checknumnum2 (num) ;
    return 0;
}