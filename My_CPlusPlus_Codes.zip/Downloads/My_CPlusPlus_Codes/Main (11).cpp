#include <iostream>
using namespace std;

int main() 
{
   short int a ;
   short int b ;

   cout << " please enter a num 1 : " << endl ; 
    cin >> a ;

   cout << " please enter a num 2 : " << endl ; 
    cin >> b  ;

    cout << a << " = " << b << " is " << ( a == b ) << endl ;
    cout << a << " != " << b << " is " << ( a != b ) << endl ;
    cout << a << " < " << b << " is " << ( a < b )  << endl ;
    cout << a << " > " << b << " is " << ( a > b )  << endl ;
    cout << a << " <= " << b << " is " << ( a <= b ) << endl ;
    cout << a << " >= " << b << " is " << ( a >= b ) << endl ;

   


    return 0;
}