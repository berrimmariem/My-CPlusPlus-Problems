#include <iostream>
using namespace std;

int main() 
{
    int sum = 0 ;
    int num = 0 ;


   for (int i = 1 ; i <= 5 ; i++) {

    cout << " enter your number : "  ;
    cin >> num ; 


     if (num > 50) {
 continue ;
}

 sum = sum + num  ;
    
    } 
    cout << sum << endl ;
    return 0;
}