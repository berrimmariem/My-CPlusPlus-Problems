#include <iostream>
using namespace std;

int main() 
{


int sum = 0 ; 
int num = 0 ;

      for (int i = 1 ; i<6 ; i++) 
      {

      cout <<"\n enter your number  : " << endl ;

      cin >> num ;


      if (num>= 50) 
      {
      cout << "wrong number";

      continue ; 

      }
      sum = sum + num ;
      }


 cout << "the sum of your numbers is : " << sum << endl ;

    return 0;
}