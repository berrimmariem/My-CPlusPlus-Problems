#include <iostream>
using namespace std;
 
 
int main() 
{
 int x[10] = {10,20,44,55,33,22,99,88,99,100} ;
 int shearchfor = 20 ;

 for (int i = 1 ; i <= 10 ; i ++ ) {
 
 cout << " we are at iteration  : " << i  << endl ; 

  if (shearchfor == x[i]) {
  
  cout << endl << shearchfor << " found at positiont " << i << endl  ; 
  break ; 
  }
 }

 
 
 
  
    return 0;
}