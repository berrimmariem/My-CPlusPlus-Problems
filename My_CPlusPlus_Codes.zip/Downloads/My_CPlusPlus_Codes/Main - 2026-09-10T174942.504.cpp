#include <iostream>
#include <string>
using namespace std;

enum thenumbersofthedays {january = 1 , february, march, april, may, june , july, august, september, october, november, december } ;

float reednumber (string message ) 
{
    float number = 0 ;
    do 
    {
       cout << message << endl ;
        cin >> number ; 

        if ( number < 1 || number > 12 ) 
        cout << " wrong number , enter a number between 1 and 12 \n " ; 
    }
       while (number < 1 || number > 12) ; 
   return number ;
}
 thenumbersofthedays checknumofdays ( int number) 
 {
    switch (number ) 
    {
        case 1 : return january ; 
        case 2 : return february ; 
        case 3 : return march ; 
        case 4 : return april ; 
        case 5 : return may ; 
        case 6 : return june ; 
        case 7 : return  july ; 
        case 8 : return august ;
        case 9 : return september ; 
        case 10 : return october ;
        case 11 : return november ;
        case 12 :return december ;
     default: return january ;
    }
 
}
void printday (thenumbersofthedays mothe) 
{
    switch (mothe) 
    {
        case january : cout << " january " ; break ; 
        case february : cout << " february " ; break ; 
        case march : cout << " march " ; break ; 
        case april : cout << " april " ; break ; 
        case may: cout << " may " ; break ; 
        case june : cout << " june " ; break ; 
        case july : cout << " july " ; break ; 
        case august : cout << " august " ; break ; 
        case september : cout << " september " ; break ; 
        case october : cout << " october " ; break ; 
        case november: cout << " november " ; break ; 
        case december: cout << " december " ; break ; 
       
     
    
    }
     cout << endl ;
}
 
int main () 
{
     int number = reednumber (" enter your number of mothe : ") ;
     thenumbersofthedays mothe = checknumofdays(number) ;

     cout << "the mothe is : \n " ;
     printday(mothe) ;
     return 0 ;

}
