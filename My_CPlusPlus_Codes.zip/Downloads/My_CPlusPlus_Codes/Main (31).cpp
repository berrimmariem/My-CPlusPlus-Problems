#include <iostream>
using namespace std;

 void functoins()
 {
 cout << "mohamed" << endl ;
 }
int main() 
{
    functoins() ;
    return 0;
}