#include <iostream>
using namespace std;

void readgreats(float x[3] )
{
    cout << " please enter gender 1 : " ;
    cin >> x[0];
    cout << " please enter gender 2 :  " ;
    cin >> x[1] ;
    cout << " please enter gender 3 : " ;
    cin >> x[2] ;
}
    float averige(float x[3])
   {
     return (x[0] + x[1] + x[2] ) /3 ; 
   }
   


int main() 
{
  float x[3] ;
   readgreats(x) ;
    cout << " the averang of gereds is : "<< averige(x);
    
    return 0;
}