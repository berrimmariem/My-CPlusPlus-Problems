#include <iostream>
#include <cmath>
using namespace std;

int reednumber (string message ) 
{
    int number = 0 ;
    cout << message << endl ;
    cin >> number ;

   return number ;
}
 float checknumber (int totalbill )
 {
  return totalbill * 1.1 * 1.16 ;
 }

int main() 
{
    float totalbill = reednumber( "enter the total bill : ")  ;
    cout << endl << "_____________________\n " ;
    cout << endl << " result is : \n" << checknumber(totalbill) << endl ;
    return 0;
}