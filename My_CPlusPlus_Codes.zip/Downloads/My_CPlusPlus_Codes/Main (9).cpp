#include <iostream>
using namespace std;

int main() 
{
    short int billvalue ;

    cout << " plaese enter billvalue : " << endl ;
    cin >> billvalue ;

     float totalbill = (billvalue * 1.1 ) + (billvalue * 1.16 ) ;
     cout << totalbill ;





    return 0;
}