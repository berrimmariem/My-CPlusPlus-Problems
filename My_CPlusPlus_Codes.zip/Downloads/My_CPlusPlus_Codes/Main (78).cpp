#include <iostream>
using namespace std;

int main() 
{
 int num ; 
 cout << " enter your number  : "  ;
cin >> num ;

 int sum = 0 ; 

 
    while (num != -99 ) {


    sum = sum + num  ;
    
    cout<< " enter anther number (if you wanne stop enter -99 ) : " << endl ;
    cin >> num ; 


    }
cout << sum ;

    return 0;
}