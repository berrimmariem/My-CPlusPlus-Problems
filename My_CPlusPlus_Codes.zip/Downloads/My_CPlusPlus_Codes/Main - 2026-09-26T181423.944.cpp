#include <iostream>
using namespace std;

float reednumber (string message ) 
{
    float number = 0 ;
    cout << message << endl ;
    cin >> number ;

   return number ;
}

bool isPrime(int number) 
{
    if (number <= 1) return false;
    if (number == 2) return true;
    if (number % 2 == 0) return false;

    for (int i = 3; i * i <= number; i += 2) {
        if (number % i == 0) return false;
    }
    return true;
}
void printprimenumbersfrom1ton (int number) 
{
    cout << "\n prime numbers from 1 to " << number << endl ;
    cout << " are : \n" ;

    for ( int i = 1 ; i <= number ; i++)
    {
        if (isPrime(i))
        {
            cout << i << endl ;
        }
    }
}


int main() 
{
    int number = reednumber("\n enter your number \n") ;
    printprimenumbersfrom1ton (number) ;
    return 0;
}