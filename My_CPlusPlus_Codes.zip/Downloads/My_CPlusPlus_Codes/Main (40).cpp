#include <iostream>
using namespace std;

int main() 
{
    float x[2] ; 
    cout << " please enter gender 1 : " ;
    cin >> x[0];
    cout << " please enter gender 2 :  " ;
    cin >> x[1] ;
    cout << " please enter gender 3 : " ;
    cin >> x[2] ;
    cout << "______________________________________\n" ;
    float avg = x[0] + x[1]  + x[2]  / 3;
    cout << avg ;
    return 0;
}