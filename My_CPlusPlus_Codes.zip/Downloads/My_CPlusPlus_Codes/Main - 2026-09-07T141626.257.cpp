#include <iostream>
using namespace std;

void reedage (short& age) 
{
    cout << " please enter your age : \n " ;
    cin >> age ; 
}
bool checkage ( short age ) 
{
    return (age >= 18 && age <= 45 ) ;
}
void printage ( short age ) 
{
    if (checkage(age)) 
   cout << "Your age is Valid \n" ;   
    else 
    cout << "Your age is Invalid \n" ;
}

int main() 
{
    short age ;
    reedage(age) ;
    printage(age) ;
    return 0;
}