#include <iostream>
using namespace std;

  void f1 () 
 {
  cout <<" *********\n"  ; 
  cout <<" *********\n"  ; 
  cout <<" *********\n"  ; 
  cout <<" *********\n"  ; 


 }


int main() 
{
     f1()  ;
    return 0;
}