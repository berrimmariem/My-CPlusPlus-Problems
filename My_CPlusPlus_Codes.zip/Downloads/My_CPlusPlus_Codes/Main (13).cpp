#include <iostream>
#include <cmath>
using namespace std;

int main() 
{
    short int a ;
    short int d ;

      cout << " please enter the num1 : \n " ;
       cin >> a ;

      cout << " please enter the num2 : \n " ;
       cin >> d ;

        int area = a * sqrt (pow (a, 2) - pow (d, 2)) ; 
          cout << " area = " << area << endl ;



    return 0;
}