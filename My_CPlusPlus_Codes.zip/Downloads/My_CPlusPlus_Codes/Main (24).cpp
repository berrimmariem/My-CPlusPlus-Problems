#include <iostream>
using namespace std;

int main() 
{
  string st1 =  " 43.22 " ;
  int num_i = stoi (st1) ;
  double num_d = stod (st1) ;
  float num_f = stof (st1) ;

  cout << num_i << endl ;
  cout << num_d << endl ;
  cout << num_f << endl ;

  int n1 = 20 ;
  string ns = to_string(n1) ;

  cout << ns << endl ;

double n2 = 33.5 ;
 string NS = to_string(n2) ;
cout << NS << endl ;

 float n3  = 55.23 ; 
 string nS = to_string(n3) ;
 int ni = static_cast<int>(n3);

 cout << nS << endl ;
 cout << ni << endl ;




    
    return 0;
}