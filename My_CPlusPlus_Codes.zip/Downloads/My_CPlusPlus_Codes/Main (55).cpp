#include <iostream>
using namespace std;

 enum  ennumbertype { odd = 1 , even = 2 } ;
 
 ennumbertype checknumbertype (int number) {


  if ( number % 2 != 0 ) 
  return ennumbertype::odd  ;

  else 
  return ennumbertype :: even ; }

  int sumnumber ( int n ) 
 {
  int sum = 0  ;

  for ( int i = 1 ; i <= n ; i ++ ) {

  if (checknumbertype(i) == ennumbertype::odd) {

  sum = sum + i  ; }

  }
 return sum ;  } 

 void printresults ( int n ) {

 cout << "sum of odd number "  << sumnumber(n) << endl ;
}
 
   
int main() 
{
    int n ;
    cout << " enter your number : " ;
    cin >> n ; 

    printresults(n) ;

    return 0;
}