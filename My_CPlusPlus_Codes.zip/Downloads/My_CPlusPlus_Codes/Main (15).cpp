#include <iostream>
#include <cmath>
using namespace std;

int main() 
{
    short int r ;
    short int pi = 3.14 ;

      cout << " please enter the num1 : \n " ;
       cin >> r ;


        double area = pi * pow (r, 2);
          cout << " area = " << area << endl ;



    return 0;
}