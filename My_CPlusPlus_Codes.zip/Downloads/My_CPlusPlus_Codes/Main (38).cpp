#include <iostream>
#include <string>
using namespace std;

 struct stbffff {
  string name ;
  string age ;
  string city ;
  string country  ;
   int mothlysalary;
   int yearlysalary ;
   char gender ;
   bool maried ;
   

   void  pf() {
    cout << "--------------------------------------\n" ;
    cout << " name  : "  ;
    cin >> name ;
    cout << " age  : "  ;
    cin >> age ;

    cout << "  city  : "  ;
    cin >> city ;

    cout << " contry   : "  ;
    cin >> country ;
  
    cout << " mothlysalary  : "  ;
    cin >> mothlysalary ;

    cout << " yearlysalary  : "  ;
    cin >> yearlysalary ;

    cout << "  gender : "  ;
    cin >> gender ;

    cout << " maried  : "  ;
    cin >> maried ;
    cout << "--------------------------------------\n" ;

  } ;

 } ;
  
int main() 
{
     stbffff person  ;
    person.pf() ;

    return 0;
}