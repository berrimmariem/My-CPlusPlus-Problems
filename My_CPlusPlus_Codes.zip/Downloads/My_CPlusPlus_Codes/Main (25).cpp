#include <iostream>
using namespace std;

  void f1 () 
 {
  cout <<" _______________________________________\n";
   cout << " name : mariem \n" ;
   cout << " age : 13 \n" ;
   cout << " city : alhachimia\n " ; 
   cout << " country : algeria " ;
  cout <<" _______________________________________\n";

 }


int main() 
{
     f1()  ;
    return 0;
}