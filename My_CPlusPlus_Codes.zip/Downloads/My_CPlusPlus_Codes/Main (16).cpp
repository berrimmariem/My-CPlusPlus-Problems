#include <iostream>
#include <cmath>
using namespace std;

int main() 
{
    short int d ;
    short int pi = 3.14 ;

      cout << " please enter the num1 : \n " ;
       cin >> d ;


        double area = ( pow (d, 2)) / (4 * pi)  ;
          cout << " area = " <<  ceil (area) << endl ;



    return 0;
}