#include <iostream>
using namespace std;

int main() 
{
    short int num1 ;
    short int num2 ;

    cout << "please enter your num1 : " << endl ;
    cin >> num1 ;

    cout << "please enter your num2 : " << endl;
    cin >> num2 ;

    if (num1 > num2) {
        cout << num1 << " is greater than " << num2 << endl ;
    }
    else if (num1 < num2) {
        cout << num1 << " is less than " << num2 << endl ;
    }
    else {
        cout << num1 << " is equal to " << num2 << endl ;
    }

    short int num3 ;
    num3 = num2 ; 
    num2 = num1 ;
    num1 = num2 ;


    return 0;
}