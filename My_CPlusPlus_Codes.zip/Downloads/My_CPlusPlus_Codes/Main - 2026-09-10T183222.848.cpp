#include <iostream>
using namespace std;

void printlitters () 
{
    for (int i = 65 ; i <= 90 ; i++) 
    {
        cout << char(i) << endl ;
    }
}

int main() 
{
      printlitters()  ;
 return 0;
}