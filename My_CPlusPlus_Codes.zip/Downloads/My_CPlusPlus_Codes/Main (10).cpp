

#include <iostream>
using namespace std;

int main() 
{
    short int d ;
    short int h ;
    short int m ;
    short int s ;

    cout << " plaese enter s : " << endl ;
    cin >> s ;


    cout << " plaese enter d : " << endl ;
    cin >> d ;

    cout << " plaese enter h : " << endl ;
    cin >> h ;

    cout << " plaese enter m : " << endl ;
    cin >> m ;


     float totals = (d*24*60*60)+(h*60*60)+(m*60)+s ;
     cout << totals ;





    return 0;
}