#include <iostream>
using namespace std;

  enum engender  {male, female};
  enum enmarried { single, maried} ;

  
 struct card 
 {
   string name ;
   int age ;
   string city ;
   string country ;
   int mothlysalary ;
   int yearlysalary ;
   engender gender ;
   enmarried married ;
 } ;

 int main() 
{
 card mycard;
 cout << "_____________________________________________________________________________\n" ;

 cout << "Name: ";
 cin >> mycard.name;

 // ... (باقي أسطر الإدخال المعتادة للعمر والمدينة والراتب)

 // إدخال الجنس:
 int genderChoice;
 cout << "Enter Gender (0 for Male, 1 for Female): ";
 cin >> genderChoice;
 mycard.gender = (engender)genderChoice; // نقوم بتحويل الرقم إلى نوع الـ Enum

 // إدخال الحالة الاجتماعية:
 int statusChoice;
 cout << "Enter Marital Status (0 for Single, 1 for Married): ";
 cin >> statusChoice;
 mycard.married = (enmarried)statusChoice;
 cout << "_____________________________________________________________________________\n" ;

    
    return 0;
}