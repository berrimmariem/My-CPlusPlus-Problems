#include <iostream>
using namespace std;

int main() 
{
    cout << "please enter a a : " << endl ;
    const float pi = 3.14 ;
    short int a ;

    cin >> a ;

    float area = (a*a) /( 4 * pi) ;
    cout << " area = (a*a) /( 4 * pi) " << endl ;


    cout << "      = (" << a << "*" << a << " ) / (" << pi << "*4 )" << endl ;
    cout << "      = " << area << endl ;



    return 0;
}