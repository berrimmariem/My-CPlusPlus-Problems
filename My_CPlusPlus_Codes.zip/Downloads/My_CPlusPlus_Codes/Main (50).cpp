#include <iostream>
using namespace std;

int main() 
{
    int day ;
    cout << " number of day : " ;
    cin>> day ;
    switch (day) {
        case 1 :
        cout << "sum" ;
        break ;
        case   2 :
        cout << " manday " ;
        break ;
        case  3 :
        cout << "tuesday" ;
        break ;
        case 4 :
        cout << "wednesday" ;
        break ;
        case 5 :
        cout << "thursday" ;
        break ;
        case 6:
        cout << "friday" ;
        break ;
        case 7 :
        cout << "saturday" ;
        break ;
        dafault :
        cout << " not a week day\n " ;
    
    }


    return 0;
}