#include <iostream>
using namespace std;

void reednumber (int& num) 
{
  cout << "enter your number : " ;
  cin >> num ;
}
void sumofoddnumber ( int & sum , int num )
{
     sum = 1 ;
    for (int i = 1 ; num >= i ; i++) 
    {
      sum = sum * i ;
    }
    
}
void print ( int sum ) 
{
    cout << " the sum is : \n " << sum << endl ;
}

int main() 
{
  int num ;
  int sum = 0 ;
  reednumber (num) ;
  sumofoddnumber (sum , num) ;
  print (sum) ;
    return 0;
}