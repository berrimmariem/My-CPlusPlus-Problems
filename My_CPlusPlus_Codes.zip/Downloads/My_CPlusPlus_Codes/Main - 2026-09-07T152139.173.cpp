#include <iostream>
using namespace std;

void reednum (int& num) 
{
    cout << " please enter your number : \n " ;
    cin >> num ; 
}
void checknum ( int num ) 
{
    for (int i = 0 ; i <= num ; i++) 
    {
      cout << i << endl ; 
    } 
 }
 
int main() 
{
    int num ;
    reednum (num) ;
    cout << " the numbers are : \n " ; 
    checknum(num) ;
    return 0;
}