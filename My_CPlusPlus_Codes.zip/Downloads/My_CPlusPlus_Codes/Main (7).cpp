#include <iostream>
#include <cmath>
using namespace std;

int main() 
{
    const float pi = 3.14 ;
    short int a ;
    short int b ;
    short int c ;

    cout << "please enter a a : " << endl ;
    cin >> a ;

    cout << "please enter a b : " << endl ;
    cin >> b ;

    cout << "please enter a c : " << endl ;
    cin >> c  ;

    float p = ( a + b + c ) /2.0 ;



    float original_area = (a*b*c) / (4 * sqrt ( p* (p-a)*(p-b)*(p-c))) ;
    float area_squared  = pow ( original_area, 2);


    cout << "area = " << area_squared << endl ;



    return 0;
}