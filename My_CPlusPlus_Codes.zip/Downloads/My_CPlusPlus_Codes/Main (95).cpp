#include <iostream>
#include <string> 
using namespace std;

struct stnumbers 
{
    int num1 ;
    int num2 ;
    int num3 ;
} ;
stnumbers reednumbers()
{
    stnumbers info ; 
   
   cout << "enter your number 1 : " << endl ;
    cin >> info.num1 ;

   cout << "enter your number 2 : " << endl ;
    cin >> info.num2 ;

   cout << "enter your number 3 : " << endl ;
    cin >> info.num3 ;

    return info ;
}
  int calculatnumbers (stnumbers info ) 
  {
    int result = (info.num1 + info.num2 + info.num3)/3 ;
    return result ;
  }
    
  void printresult (stnumbers info )
  {
    cout << " the sum of your numbers it is : "  << calculatnumbers (info) << endl ;
  }
int main() 
{
    stnumbers numbers = reednumbers() ;
    printresult(numbers) ;
    return 0;
}