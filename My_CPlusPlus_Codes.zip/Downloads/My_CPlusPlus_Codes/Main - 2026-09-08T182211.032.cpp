#include <iostream>
#include <cmath>
using namespace std;

 int  reednum ( int & mark )
 {
    cout << "enter your mark : \n " ;
    cin >> mark ; 

    return mark ;
 }

 char numbers (int & mark )
 {
    while ( mark > 100 || mark < 0 ) 
    {
        cout << " error , enter your mark : \n " ;
        cin >> mark ; 
    }
    if ( mark >= 90 ) 
    {
      return 'A' ; 
    }
    else if ( mark >= 80 )
    {
      return 'B'; 
    }
    else if ( mark >= 70 ) 
    {
      return 'C' ; 
    }
    else if ( mark >= 60 ) 
    {
      return 'D' ;
    }
    else if ( mark >= 50 )
    {
      return 'E' ;
    }
    else 
    {
      return 'F' ;
    }
 }
 

int main() 
{
    int mark ;
    reednum(mark) ;
    cout << " your greate is : " << numbers(mark) << endl ;
    return 0;
}