#include <iostream>
using namespace std;

int main() 
{
  for (char c = 'A' ; c <= 'Z' ; c++ ) 
  {
   cout << "c1 = " << c << endl << "------" << endl << endl  ;

    for (char j = 'A' ; j <= 'Z' ; j++) 
    {
    cout << c << j << "\n " ;
    }

cout << "__________________________________________\n" ;

  }

    return 0;
}