#include <iostream>
using namespace std;

 enum enfialdpass {fail = 1 , pass = 2 } ;

 int reedmark()
 {
    int mark ;
    cout << "enter your mark : " ;
    cin >> mark ;

    return mark ;
 }
 int checkmark (int mark) 
 {
   if (50 >= mark ) 
    return enfialdpass::fail ;
   else 
    return enfialdpass::pass ;
 }
 void printresult (int mark)
 {
   if (checkmark(mark) == enfialdpass::pass )
    cout << " \n you are passed \n " ;

   else 
    cout << " \n you are failed \n " ;
 }
int main() 
{
  printresult(reedmark()) ;
    return 0;
}