#include <iostream>
#include <string>
using namespace std;

struct stcard 
{
 string fullname ;
 string lastname;
 short age ;
 string phone ;
};
void mimi(stcard&info)
{
    cout << "please enter full name : " << endl ;
    cin >> info.fullname ;

    cout << "please enter last name : " << endl ;
    cin >>  info.lastname ;

    cout << "please enter age :  " << endl ;
    cin >> info.age  ;

    cout << "please enter number of phone :  " << endl ;
    cin >> info.phone ;

}
  void nini(stcard info)
  {
 cout << "____________________________________\n";
 cout << "fullname : "<< info.fullname << endl ;
 cout << "lastname : " << info.lastname<< endl ;
 cout << "age : "  << info.age << endl ;
 cout << "phone : " << info.phone <<endl ; 
 cout << "____________________________________\n";
  }
  void cocy (stcard person[2])
  {
    mimi(person[0]) ;
    mimi(person[1]) ;
  }
  void byby(stcard person[2])
  {
    nini(person[0]) ;
    nini(person[1]) ;

  }

int main() 
{
    stcard person[2] ;
    cocy (person) ;
    byby (person) ;

    return 0;
}