#include <iostream>
using namespace std;

  struct owaner 
  {
  int phon_num ;
  string addriss ;
    
  };

 struct card 
  {
    string name ; 
    int  age ; 
    string city ; 
    string country ; 
     int  monthlysalary ; 
      int yearlysalary ; 
     char  gender ;
     bool married  ;
     owaner m1 ;
  } ;
   int main() 
{
  
  
    card mycard ; 
    cout <<"*****************************************\n " ;
    cout << " Name : " ;
    cin >> mycard.name ;
    cout << " Age : " ; 
    cin >> mycard.age ;
    cout << " city : " ; 
    cin >> mycard.city ; 
    cout << " country : " ; 
    cin >> mycard.country ;
    cout << " monthly salary : " ;
    cin >> mycard.monthlysalary ;
    cout << " yearly salary : " ; 
    cin >> mycard.yearlysalary ;
    cout << " gender : " ; 
    cin >> mycard.gender;
    cout << " married : "  ; 
    cin >> mycard.married ;
    cout << " phon_num " ;
    cin >> mycard.m1.phon_num ;
    cout << " addriss : " ;
    cin>> mycard.m1.addriss ;
    cout <<"*****************************************\n " ;



















    return 0;
}

