#include <iostream>
#include <string>
#include <cmath>
using namespace std;

struct sttime 
{
    int days, hours , minutes , scond ;
} ;
float reednumber (string message ) 
{
    float number = 0 ;
    cout << message << endl ;
    cin >> number ;

   return number ;
}
 sttime stbf ( int totalscond ) 
 {
    sttime m ;
    const  int scondsperday = 24 * 60 * 60 ;
    const int scondsperhour = 60 * 60 ;
    const int scondsperminute = 60 ;

    int remainder = 0 ;
     m.days = totalscond / scondsperday  ;
     remainder = totalscond % scondsperday ;

     m.hours = remainder / scondsperhour  ;
     remainder = remainder % scondsperhour ; 

     m.minutes =  remainder / scondsperminute  ;
     remainder = remainder % scondsperminute ;

     m.scond = remainder ;
   
   return m ;
    
 }
 void printm (sttime m ) 
 {
    cout << "\n______________________________\n" ;
    cout << m.days << ":";
    cout << m.hours << ":";
    cout << m.minutes << ":";
    cout << m.scond << ;
    cout << "\n______________________________\n" ;

 }
int main () 
{
    int totalscond = reednumber (" Enter your total sconds : \n") ;
    printm (stbf(totalscond)) ;
     return 0 ;

}
