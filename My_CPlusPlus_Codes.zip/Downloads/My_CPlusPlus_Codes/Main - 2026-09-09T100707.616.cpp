#include <iostream>
#include <cmath>
using namespace std;

int reednumber (string message ) 
{
    int number = 0 ;
    cout << message << endl ;
    cin >> number ;

   return number ;
}
 float checknumber (int totalbill ,int totalckachbill )
 {
  return totalbill - totalckachbill ;
 }

int main() 
{
   float totalbill = reednumber( "enter the total bill : ")  ;
  float  totalckachbill = reednumber( "enter the total cash paid : ")  ;
    cout << endl << "_____________________\n " ;
    cout << endl << " result is : \n" << checknumber(totalbill,totalckachbill) << endl ;
    return 0;
}