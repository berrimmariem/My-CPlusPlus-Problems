#include <iostream>
using namespace std;

int main() 
{
int num ; 
cout << "please enter your code  : " ;
cin >> num ; 

 int sum = 0 ;

while (num != 1234 && sum < 3) {
sum = sum + 1 ; 

  if ( 3==sum ) {
  cout << "card locked" ;
  break ;
  }
  cout << "  wrong code,please enter your code  : " ;
cin >> num ; 
}
   if ( 1234 == num ){
   
    cout << "blance : 7500 " ; 
   }
   
    
  
  
   
return 0;
 }